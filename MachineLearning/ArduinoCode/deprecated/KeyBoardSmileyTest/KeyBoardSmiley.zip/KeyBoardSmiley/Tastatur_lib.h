#ifndef KEYBOARD_LIB_H
#define KEYBOARD_LIB_H

void printToKeyboard(String s);

#endif
